module.exports = {
    multipleStatements  : true,
    host                : 'localhost',
    user                : 'sita_dbcampus',
    password            : 'root',
    database            : 'sita_dbcampus'
};