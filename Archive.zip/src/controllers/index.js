const jurusan = require('./controller-jurusan');

module.exports ={
	jurusan
};
